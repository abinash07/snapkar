<?php
    $base_url = "http://localhost/snapkar/";

    date_default_timezone_set("Asia/Kolkata");

?>