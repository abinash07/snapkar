    <script src="<?= $base_url; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $base_url; ?>assets/js/main.js"></script>
</body>
</html>